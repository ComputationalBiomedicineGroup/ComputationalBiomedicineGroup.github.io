# -----------------------------------------------
# Course: Introduction to Programming with R
# Session 05: Conditional execution
# State of water exercise (tinytests)
# -----------------------------------------------

library('tinytest')

expect_silent(state_of_water(0))

# expect_equal(state_of_water("a"), "gas")      
# expect_error(state_of_water("a"))

expect_equal(state_of_water(-0.01), "solid")
expect_equal(state_of_water(0), "liquid")
expect_equal(state_of_water(99.99), "liquid")
expect_equal(state_of_water(100), "gas")

## Check that the function contains at least one explicit return,
## and that an explicit return is in the last part (last few lines)
## of the function.
parse_function <- function(f) {
    src <- deparse(f)
    return(src[sapply(src, function(x) nchar(trimws(x))) > 0])
}
src <- parse_function(state_of_water)
idx_return <- grep("^\\s+(invisible|return)(\\s+)?\\(", src)
expect_true(length(idx_return) > 0,
            info = "No explicit return found. Make sure to call return() or invisible().")
expect_true(ifelse(length(idx_return) > 0, max(idx_return) >= length(src) - 3, FALSE),
            info = "No explicit return found at the end of the function!")
