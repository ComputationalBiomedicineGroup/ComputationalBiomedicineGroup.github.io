# -----------------------------------------------
# Course: Introduction to Programming with R
# Session 05: Conditional execution
# Temperature conversion exercise (tinytests)
# -----------------------------------------------

library('tinytest')

# definition of function
expect_silent(convert_temperature(0, "celsius", "kelvin"))

# error handling
expect_warning(convert_temperature("a", "celsius", "kelvin"))
expect_warning(convert_temperature("0", "celsius", "kelvin"))
expect_error(convert_temperature(0, "rankine", "kelvin"))

# wrong argument names/missing arguments
expect_error(convert_temperature())                                 # missing all arguments
expect_error(convert_temperature(from = "celsius", to = "kelvin"))  # missing x
expect_error(convert_temperature(x = 15, from = "celsius"))         # missing to
expect_error(convert_temperature(x = 15, to = "kelvin"))            # missing from

# calulations
expect_equal(convert_temperature(0, "celsius", "kelvin"), 273.15)
expect_equal(convert_temperature(convert_temperature(0, "celsius", "kelvin"), "kelvin", "celsius"), 0)

# ... with Kelvin 
expect_equal(convert_temperature(273.15, "kelvin", "celsius"), 0)
expect_equal(convert_temperature(273.15, "kelvin", "fahrenheit"), 32)
expect_equal(round(convert_temperature(100, "fahrenheit", "kelvin"), 1), 310.9)

# Check that the function contains at least one explicit return,
# and that an explicit return is in the last part (last few lines)
# of the function.
parse_function <- function(f) {
    src <- deparse(f)
    return(src[sapply(src, function(x) nchar(trimws(x))) > 0])
}
src <- parse_function(convert_temperature)
idx_return <- grep("^\\s+(invisible|return)(\\s+)?\\(", src)
expect_true(length(idx_return) > 0,
            info = "No explicit return found. Make sure to call return() or invisible().")
expect_true(ifelse(length(idx_return) > 0, max(idx_return) >= length(src) - 3, FALSE),
            info = "No explicit return found at the end of the function!")
